export class TaskNotFound extends Error {
    constructor(message) {
        super(message);
    }
}